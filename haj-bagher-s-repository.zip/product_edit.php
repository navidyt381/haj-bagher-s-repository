<?php
include("up.php");

$isAdmin = false;
if (isset($_SESSION["login"]) && isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    $connect = mysqli_connect("localhost", "hajbag_root", "Nn123456*", "hajbag_parsnovindb");
    if ($connect) {
        $query = "SELECT admin FROM users WHERE name='$username'";
        $result = mysqli_query($connect, $query);
        if ($result && $row = mysqli_fetch_array($result)) {
            if ($row["admin"] == 1) {
                $isAdmin = true;
            }
        }
        mysqli_close($connect);
    }
}
if  ($isAdmin==false) {
?>
<script>location.replace("index.php");</script>
<?php } 
$id = $_GET["id"];
$connect = mysqli_connect("localhost", "root", "", "parsnovindb");
$result = mysqli_query($connect, "SELECT * FROM products WHERE id='$id'");
$row = mysqli_fetch_array($result);
mysqli_close($connect);
?>
<main class="container my-5">
    <h2 class="text-center mb-4">ویرایش محصول</h2>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="product_edit_action.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="mb-3">
                    <label for="title" class="form-label">عنوان محصول</label>
                    <input type="text" class="form-control" id="title" name="title" value="<?php echo $row['title']; ?>">
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">قیمت</label>
                    <input type="text" class="form-control" id="price" name="price" value="<?php echo $row['price']; ?>">
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">تصویر جدید (اختیاری)</label>
                    <input type="file" class="form-control" id="image" name="image">
                    <?php if(!empty($row['image'])) { ?>
                        <img src="<?php echo $row['image']; ?>" alt="تصویر کنونی" class="img-thumbnail mt-2" style="max-width: 200px;">
                    <?php } ?>
                </div>
                <button type="submit" class="btn btn-success w-100">ذخیره تغییرات</button>
            </form>
        </div>
    </div>
</main>
<?php
include("down.html");
?>
