<?php include("up.php"); ?>

<section class="container my-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow">
        <div class="card-header bg-success text-white text-center">
          <h2>درباره ما</h2>
        </div>
        <div class="card-body">
          <p dir="rtl">
            تیم نوین پارس فعالیت خود را از سال 1403 شروع کرده و در زمینه خرید و فروش قطعات کامپیوتر فعالیت میکند
          </p>
          <p dir="rtl">
            نشانی ما در فضای مجازی
          </p>
          <p dir="rtl">ig:parsnovin_ir</p>
          <p dir="rtl">tg:parsnovinsupport</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include("down.html"); ?>